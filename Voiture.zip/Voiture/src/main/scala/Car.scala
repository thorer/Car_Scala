case class Car[A] extends Vehicule[A]{}
