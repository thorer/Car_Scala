sealed abstract class Vehicule[A] {

}
