case class Boat[A] extends Vehicule[A]{}

